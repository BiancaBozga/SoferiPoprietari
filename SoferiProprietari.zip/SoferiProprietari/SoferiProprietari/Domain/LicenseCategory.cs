namespace SoferiProprietari.Domain;

public enum LicenseCategory
{
    A, B, C
}