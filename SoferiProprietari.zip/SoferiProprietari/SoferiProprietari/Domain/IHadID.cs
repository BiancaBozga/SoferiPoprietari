namespace SoferiProprietari.Domain;

public interface IHadID<ID>
{
     public ID Id { get; set; }
}