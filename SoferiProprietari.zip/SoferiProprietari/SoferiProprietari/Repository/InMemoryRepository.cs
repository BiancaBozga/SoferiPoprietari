using SoferiProprietari.Domain;

namespace SoferiProprietari.Repository;

public class InMemoryRepository<ID, E> : IRepository<ID, E> where E : IHadID<ID>
{
    protected IDictionary<ID, E> _dictionary = new Dictionary<ID, E>();
        
    public E FindOne(ID id)
    {
        _dictionary.TryGetValue(id, out var entity);
        return entity;
    }

    public IEnumerable<E> FindAll()
    {
        return _dictionary.Values;
    }

    public E Save(E entity)
    {
        try
        {
            _dictionary.Add(entity.Id, entity);
            return default;
        }
        catch (ArgumentException exception)
        {
            return entity;
        }
    }
    
}